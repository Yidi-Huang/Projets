# Fichiers dans le zip :

1. dossier **corpus** : 
\
contenant tous les fichiers textes

2. **mot_vide.txt** : 
\
pour supprimer les mots vides du corpus

3. **Rapport_weka_CHENG_Weixuan-HUANG_Yidi.pdf** : 
\
rapport du projet

4. **vectorisation.py** :
\
script un peu modifié pour un corpus lemmatisé
